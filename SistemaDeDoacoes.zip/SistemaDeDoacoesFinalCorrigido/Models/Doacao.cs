using System;

namespace SistemaDeDoacoes.Models;

public class Doacao
{
    public int Id { get; set; }
    public string Doador { get; set; }
    public string Item { get; set; }
    public int Quantidade { get; set; }
    public DateTime Data { get; set; }
}
