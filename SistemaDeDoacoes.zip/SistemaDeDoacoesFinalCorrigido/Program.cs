using System;
using System.Linq;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.OpenApi.Models; // necessário para Swagger

using SistemaDeDoacoes.Data;
using SistemaDeDoacoes.Models;
using SistemaDeDoacoes.Routes;

var builder = WebApplication.CreateBuilder(args);

// Configuração do banco de dados SQLite
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlite("Data Source=doacoes.db"));

// Configuração do Swagger
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "Sistema de Doações",
        Version = "v1"
    });
});

var app = builder.Build();

// Criação e seed do banco de dados
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    db.Database.EnsureCreated();

    if (!db.Doacoes.Any())
    {
        db.Doacoes.AddRange(new List<Doacao>
        {
            new() { Doador = "João", Item = "Roupas", Quantidade = 10, Data = DateTime.Now },
            new() { Doador = "Maria", Item = "Alimentos", Quantidade = 5, Data = DateTime.Now },
            new() { Doador = "Carlos", Item = "Brinquedos", Quantidade = 7, Data = DateTime.Now },
            new() { Doador = "Ana", Item = "Livros", Quantidade = 12, Data = DateTime.Now },
            new() { Doador = "Rafael", Item = "Material escolar", Quantidade = 15, Data = DateTime.Now },
            new() { Doador = "Lucia", Item = "Cestas básicas", Quantidade = 8, Data = DateTime.Now },
            new() { Doador = "Pedro", Item = "Máscaras", Quantidade = 20, Data = DateTime.Now },
            new() { Doador = "Fernanda", Item = "Álcool em gel", Quantidade = 14, Data = DateTime.Now },
            new() { Doador = "Bruno", Item = "Cobertores", Quantidade = 9, Data = DateTime.Now },
            new() { Doador = "Juliana", Item = "Calçados", Quantidade = 6, Data = DateTime.Now }
        });

        db.SaveChanges();
    }
}

// Mapeamento das rotas
GetAll.Map(app);
GetById.Map(app);
Post.Map(app);
Delete.Map(app);

// Ativação do Swagger na raiz
app.UseSwagger();
app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("/swagger/v1/swagger.json", "Sistema de Doações API V1");
    c.RoutePrefix = string.Empty;
});

app.Run();