using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using SistemaDeDoacoes.Data;
using SistemaDeDoacoes.Models;

namespace SistemaDeDoacoes.Routes;

public static class GetById
{
    public static void Map(WebApplication app)
    {
        app.MapGet("/api/doacoes/{id}", async (int id, AppDbContext db) =>
        {
            var doacao = await db.Doacoes.FindAsync(id);
            return doacao is not null ? Results.Ok(doacao) : Results.NotFound();
        });
    }
}
