using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using SistemaDeDoacoes.Data;
using SistemaDeDoacoes.Models;

namespace SistemaDeDoacoes.Routes;

public static class Post
{
    public static void Map(WebApplication app)
    {
        app.MapPost("/api/doacoes", async (Doacao doacao, AppDbContext db) =>
        {
            db.Doacoes.Add(doacao);
            await db.SaveChangesAsync();
            return Results.Created($"/api/doacoes/{doacao.Id}", doacao);
        });
    }
}
