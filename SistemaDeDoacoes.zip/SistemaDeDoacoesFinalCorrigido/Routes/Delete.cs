using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using SistemaDeDoacoes.Data;

namespace SistemaDeDoacoes.Routes;

public static class Delete
{
    public static void Map(WebApplication app)
    {
        app.MapDelete("/api/doacoes/{id}", async (int id, AppDbContext db) =>
        {
            var doacao = await db.Doacoes.FindAsync(id);
            if (doacao == null) return Results.NotFound();
            db.Doacoes.Remove(doacao);
            await db.SaveChangesAsync();
            return Results.NoContent();
        });
    }
}
