using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using SistemaDeDoacoes.Data;
using SistemaDeDoacoes.Models;

namespace SistemaDeDoacoes.Routes;

public static class GetAll
{
    public static void Map(WebApplication app)
    {
        app.MapGet("/api/doacoes", async (AppDbContext db) =>
        {
            return await db.Doacoes.ToListAsync();
        });
    }
}
